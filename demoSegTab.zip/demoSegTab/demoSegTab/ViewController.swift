//
//  ViewController.swift
//  demoSegTab
//
//  Created by Yogesh Patel on 02/05/18.
//  Copyright © 2018 Yogesh Patel. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var tableView: UITableView!
    @IBOutlet var segOut: UISegmentedControl!
    var ahData:[AhmedabadModel] = []
    var baData:[BangloreModel] = []
    var muData:[MumbaiModel] = []
    var puData:[PuneModel] = []
    override func viewDidLoad() {
        super.viewDidLoad()        
       ahData = [
        AhmedabadModel(city:"City :- Ahmedabad",img:  #imageLiteral(resourceName: "a1"), title: "Navratri"),
        AhmedabadModel(city:"City :- Ahmedabad",img:  #imageLiteral(resourceName: "a2"), title: "Rann Utsav"),
        AhmedabadModel(city:"City :- Ahmedabad",img:  #imageLiteral(resourceName: "a3"), title: "Shamlaji Melo"),
        AhmedabadModel(city:"City :- Ahmedabad",img:  #imageLiteral(resourceName: "a4"), title: "International Kite Festival (Uttarayan)"),
        AhmedabadModel(city:"City :- Ahmedabad",img:  #imageLiteral(resourceName: "a5"), title: "Bhavnath Mahadev Fair"),
        AhmedabadModel(city:"City :- Ahmedabad",img:  #imageLiteral(resourceName: "a6"), title: "Rath Yatra"),
        AhmedabadModel(city:"City :- Ahmedabad",img:  #imageLiteral(resourceName: "a7"), title: "Janmashtami")
        ]
        
        muData = [
            MumbaiModel(city: "City :- Mumbai", img:  #imageLiteral(resourceName: "m1"), title: "Banganga (Jan)"),
            MumbaiModel(city: "City :- Mumbai", img:  #imageLiteral(resourceName: "m2"), title: "Elephanta festival (Feb)"),
            MumbaiModel(city: "City :- Mumbai", img:  #imageLiteral(resourceName: "m3"), title: "Gudhi Padava (Mar-Apr)"),
            MumbaiModel(city: "City :- Mumbai",img:  #imageLiteral(resourceName: "m4"), title: "Ganesh Chaturthi (Aug-Sep)"),
            MumbaiModel(city: "City :- Mumbai",img:  #imageLiteral(resourceName: "m5"), title: "Diwali(Oct-Nov)")
        ]
        
        baData = [
            BangloreModel(city: "City :- Banglore", img:  #imageLiteral(resourceName: "b1"), title: "Karaga Festival"),
            BangloreModel(city: "City :- Banglore", img:  #imageLiteral(resourceName: "b2"), title: "Kadalekai Parishe Festival"),
            BangloreModel(city: "City :- Banglore", img:  #imageLiteral(resourceName: "b3"), title: "Makar Sankranti"),
            BangloreModel(city:"City :- Banglore",img:  #imageLiteral(resourceName: "b4"), title: "Ugadi Festival"),
            BangloreModel(city:"City :- Banglore",img:  #imageLiteral(resourceName: "b5"), title: "Varamahalakshmi Festival")
        ]
        
        puData = [
            PuneModel(city: "City :- Pune", img:  #imageLiteral(resourceName: "p1"), title: "Makar Sankranti"),
            PuneModel(city: "City :- Pune", img:  #imageLiteral(resourceName: "p2"), title: "Vasant Panchami"),
            PuneModel(city:"City :- Pune",img:  #imageLiteral(resourceName: "p3"), title: "Holi"),
            PuneModel(city:"City :- Pune",img:  #imageLiteral(resourceName: "p4"), title: "Gudi Padwa"),
            PuneModel(city:"City :- Pune",img:  #imageLiteral(resourceName: "p5"), title: "Nag Panchami")
        ]
    }
    

    @IBAction func btnSegClick(_ sender: UISegmentedControl) {
        self.tableView.reloadData()
    }
}

extension ViewController: UITableViewDelegate, UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        var value = 0
        switch segOut.selectedSegmentIndex{
        case 0:
            value = ahData.count
            break
        case 1:
            value = muData.count
            break
        case 2:
            value = baData.count
            break
        case 3:
            value = puData.count
            break
        default:
            break
        }
        return value
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TableViewCell", for: indexPath) as! TableViewCell
        switch segOut.selectedSegmentIndex{
        case 0:
           cell.ahModel = ahData[indexPath.row]
            break
        case 1:
            cell.muModel = muData[indexPath.row]
            break
        case 2:
            cell.baModel = baData[indexPath.row]
            break
        case 3:
            cell.puModel = puData[indexPath.row]
            break
        default:
            break
        }
        return cell
    }
    
    
}













