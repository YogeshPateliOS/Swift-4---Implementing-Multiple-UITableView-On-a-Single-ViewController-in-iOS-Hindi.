//
//  DataModel.swift
//  demoSegTab
//
//  Created by Yogesh Patel on 02/05/18.
//  Copyright © 2018 Yogesh Patel. All rights reserved.
//

import Foundation
import UIKit
struct AhmedabadModel{
    let city:String?
    let img:UIImage?
    let title:String?
}

struct MumbaiModel{
    let city:String?
    let img:UIImage?
    let title:String?
}

struct BangloreModel{
    let city:String?
    let img:UIImage?
    let title:String?
}

struct PuneModel{
    let city:String?
    let img:UIImage?
    let title:String?
}
